The software was developed in Android Studio 3.6.1 on windows 10, personal machine. Needs to be android studio 3.6 or newer to run it
To run the code:
1.) Open an existing android studio project
2.) Navigate to the EPIC app path, and select OK on the EPIC App.
3.) Create an emulator that matches the specs below:

Code has been tested on a Pixel 2XL running API 24 running android 7 & two mobile devices:
- Motorola G4 running android 7
- Google Pixel 3a running android 10 

(If you want to test the AR capabilities you will require a device running 7.0 and that it is supported by ARCORE (https://developers.google.com/ar/discover/supported-devices)
- Application Tests were run on the Pixel 2XL running API 24 running android seven emulator

The APK can be located at:
Epic\app\build\outputs\apk\debug